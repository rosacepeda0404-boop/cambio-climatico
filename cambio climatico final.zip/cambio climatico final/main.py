import json
import random
import tkinter as tk
from datetime import datetime
from pathlib import Path
from tkinter import messagebox, ttk


preguntas = [
    {
        "pregunta": "Tu escuela puede instalar una sola mejora este año. ¿Cuál ayuda más a usar energía limpia?",
        "tema": "energía limpia",
        "opciones": ["Paneles solares en el techo", "Más generadores a gasolina", "Dejar luces encendidas"],
        "correcta": 0,
        "explicacion": "La energía solar es renovable y ayuda a reducir la contaminación.",
    },
    {
        "pregunta": "Vas a comprar una bebida para llevar. ¿Qué decisión evita más residuos?",
        "tema": "reciclaje",
        "opciones": ["Llevar una botella reutilizable", "Elegir una botella de un solo uso", "Pedir dos vasos desechables"],
        "correcta": 0,
        "explicacion": "Usar un recipiente reutilizable evita residuos de un solo uso.",
    },
    {
        "pregunta": "Un bosque cercano está amenazado por la tala. ¿Qué acción protege mejor su aporte al clima?",
        "tema": "bosques",
        "opciones": [
            "Proteger el bosque y restaurar las zonas dañadas",
            "Cambiar el bosque por estacionamientos",
            "Quemar madera para limpiar el terreno",
        ],
        "correcta": 0,
        "explicacion": "Los bosques absorben dióxido de carbono y ayudan al planeta.",
    },
    {
        "pregunta": "Cuatro compañeros van al mismo lugar. ¿Qué opción suele emitir menos por persona?",
        "tema": "transporte",
        "opciones": ["Un autobús lleno", "Un coche con una sola persona", "Un avión privado"],
        "correcta": 0,
        "explicacion": "Compartir el autobús ayuda a reducir las emisiones por pasajero.",
    },
    {
        "pregunta": "Sales de casa y ves luces y aparatos encendidos en habitaciones vacías. ¿Qué haces?",
        "tema": "ahorro de energía",
        "opciones": [
            "Apagar luces y aparatos que no se necesitan",
            "Dejarlos encendidos por si alguien vuelve",
            "Encender otros aparatos para aprovecharlos",
        ],
        "correcta": 0,
        "explicacion": "Apagar las luces cuando no se necesitan reduce el consumo de energía.",
    },
    {
        "pregunta": "¿Qué significa que una especie esté en peligro de extinción?",
        "tema": "biodiversidad",
        "opciones": [
            "Que quedan muy pocos ejemplares y podría desaparecer",
            "Que vive en muchos países",
            "Que acaba de descubrirse",
        ],
        "correcta": 0,
        "explicacion": "Proteger los hábitats ayuda a las especies amenazadas a sobrevivir.",
    },
    {
        "pregunta": "En una tienda te ofrecen una bolsa aunque solo compraste un artículo pequeño. ¿Qué eliges?",
        "tema": "plásticos",
        "opciones": [
            "Rechazar la bolsa o usar una bolsa reutilizable",
            "Pedir una bolsa nueva para cada compra",
            "Elegir una bolsa aunque no la necesite",
        ],
        "correcta": 0,
        "explicacion": "Los objetos reutilizables evitan generar residuos de un solo uso.",
    },
    {
        "pregunta": "Preparaste demasiada comida y sobran cáscaras de frutas y verduras. ¿Qué opción es mejor?",
        "tema": "composta",
        "opciones": [
            "Tirarlos siempre en la calle",
            "Hacer composta cuando sea posible",
            "Mezclarlos con pilas usadas",
        ],
        "correcta": 1,
        "explicacion": "La composta transforma residuos orgánicos en abono para las plantas.",
    },
    {
        "pregunta": "¿Por qué es importante cuidar los océanos?",
        "tema": "océanos",
        "opciones": [
            "Porque son hogar de muchas especies y ayudan a regular el clima",
            "Porque toda la basura desaparece en el mar",
            "Porque no tienen relación con la vida del planeta",
        ],
        "correcta": 0,
        "explicacion": "Los océanos sostienen una gran diversidad de vida y son importantes para el clima.",
    },
    {
        "pregunta": "Notas que el grifo sigue abierto mientras te cepillas los dientes. ¿Qué cambio ayuda?",
        "tema": "ahorro de agua",
        "opciones": [
            "Cerrar el grifo mientras te cepillas",
            "Dejarlo abierto para enjuagar más rápido",
            "Abrir otro grifo al mismo tiempo",
        ],
        "correcta": 0,
        "explicacion": "Cerrar el grifo durante el cepillado evita desperdiciar agua potable.",
    },
    {
        "pregunta": "¿Qué es una fuente de energía renovable?",
        "tema": "energía renovable",
        "opciones": [
            "La energía del viento",
            "El carbón",
            "La gasolina",
        ],
        "correcta": 0,
        "explicacion": "El viento se renueva de forma natural y puede generar electricidad.",
    },
    {
        "pregunta": "¿Qué gas contribuye especialmente al calentamiento global?",
        "tema": "gases de efecto invernadero",
        "opciones": ["Dióxido de carbono (CO₂)", "Oxígeno", "Helio"],
        "correcta": 0,
        "explicacion": "El CO₂ atrapa calor en la atmósfera; reducir sus emisiones ayuda a frenar el calentamiento.",
    },
    {
        "pregunta": "Compraste más verduras de las que puedes comer esta semana. ¿Cómo evitas desperdiciarlas?",
        "tema": "desperdicio de alimentos",
        "opciones": [
            "Planear las compras y aprovechar las sobras",
            "Comprar más de lo que necesitamos",
            "Tirar la comida al terminar el día",
        ],
        "correcta": 0,
        "explicacion": "Planear las comidas y guardar las sobras reduce residuos y el uso de recursos.",
    },
    {
        "pregunta": "Quieres ayudar a las abejas en tu jardín. ¿Qué cambio ofrece alimento y refugio?",
        "tema": "polinizadores",
        "opciones": [
            "Plantar flores variadas y nativas",
            "Quitar todas las plantas con flores",
            "Usar pesticidas sin necesidad",
        ],
        "correcta": 0,
        "explicacion": "Las flores ofrecen alimento y refugio a polinizadores esenciales para muchos ecosistemas.",
    },
    {
        "pregunta": "El destino está a diez minutos caminando y tienes tiempo. ¿Qué opción evita emisiones del viaje?",
        "tema": "transporte sostenible",
        "opciones": ["Caminar o ir en bicicleta", "Ir solo en coche", "Tomar un avión"],
        "correcta": 0,
        "explicacion": "Caminar o usar bicicleta no genera emisiones directas y también beneficia la salud.",
    },
    {
        "pregunta": "Tu comunidad sufre olas de calor cada verano. ¿Qué medida ayuda a prepararse?",
        "tema": "adaptación climática",
        "opciones": [
            "Crear espacios con sombra y avisos para proteger a personas vulnerables",
            "Quitar los árboles para que llegue más sol",
            "Ignorar las alertas de calor",
        ],
        "correcta": 0,
        "explicacion": "Adaptarse significa prepararse y reducir los daños de los efectos climáticos.",
    },
    {
        "pregunta": "Hay inundaciones frecuentes cerca de un humedal. ¿Qué acción aprovecha su función natural?",
        "tema": "humedales",
        "opciones": [
            "Conservar el humedal para que retenga parte del exceso de agua",
            "Rellenarlo con tierra y construir encima",
            "Drenarlo para que desaparezca",
        ],
        "correcta": 0,
        "explicacion": "Los humedales albergan biodiversidad, filtran agua y pueden ayudar a reducir inundaciones.",
    },
    {
        "pregunta": "¿Cuál de estas acciones puede reducir el consumo de energía?",
        "tema": "ahorro de energía",
        "opciones": [
            "Usar focos LED",
            "Dejar la puerta del refrigerador abierta",
            "Mantener aparatos encendidos sin usarlos",
        ],
        "correcta": 0,
        "explicacion": "Los focos LED suelen usar menos electricidad que los focos tradicionales.",
    },
    {
        "pregunta": "¿Qué significa reutilizar un objeto?",
        "tema": "reutilización",
        "opciones": [
            "Volver a usarlo en vez de tirarlo",
            "Usarlo una vez y desecharlo",
            "Comprar otro igual sin necesitarlo",
        ],
        "correcta": 0,
        "explicacion": "Reutilizar alarga la vida de los objetos y ayuda a disminuir la basura.",
    },
    {
        "pregunta": "¿Cómo podemos ayudar a cuidar los árboles de la ciudad?",
        "tema": "árboles urbanos",
        "opciones": [
            "Protegerlos y cuidar las áreas verdes",
            "Romper sus ramas por diversión",
            "Cubrir sus raíces con cemento",
        ],
        "correcta": 0,
        "explicacion": "Los árboles dan sombra, capturan carbono y ofrecen espacios para la vida silvestre.",
    },
]


class Cuestionario:
    def __init__(self, ventana):
        self.ventana = ventana
        self.ventana.title("Salva el planeta")
        self.ventana.geometry("1050x850")
        self.ventana.minsize(820, 720)
        self.ventana.configure(bg="#071b2e")

        self.indice = 0
        self.puntos = 0
        self.salud = 50
        self.nombre_jugador = ""
        self.temas_correctos = []
        self.temas_por_mejorar = []
        self.preguntas_partida = []
        self.respuesta_en_proceso = False
        self.archivo_historial = Path(__file__).with_name("historial_partidas.json")
        self.historial_guardable = True
        self.historial = self.cargar_historial()
        self.botones_animando = set()

        self.lobby = tk.Frame(ventana, bg="#071b2e")
        self.lobby.pack(fill="both", expand=True)
        self.mostrar_lobby()

    def mostrar_lobby(self):
        tk.Label(
            self.lobby,
            text="🌎  SALVA EL PLANETA  🌱",
            font=("Arial", 32, "bold"),
            bg="#102a43",
            fg="#00f5d4",
            padx=20,
            pady=22,
        ).pack(fill="x", padx=45, pady=(45, 24))

        tk.Label(
            self.lobby,
            text="🌱  PIENSA EN VERDE. ACTÚA POR EL FUTURO.  ⚡\n"
            "Cada pequeña acción puede cambiar nuestro planeta.",
            font=("Arial", 19, "bold"),
            bg="#071b2e",
            fg="#f7f7ff",
            justify="center",
        ).pack(pady=25)

        tk.Label(
            self.lobby,
            text="ESCRIBE TU NOMBRE",
            font=("Arial", 18, "bold"),
            bg="#071b2e",
            fg="#ff4dce",
        ).pack(pady=(18, 8))

        self.entrada_nombre = tk.Entry(
            self.lobby,
            font=("Arial", 20),
            justify="center",
            width=28,
            relief="flat",
            bd=0,
            bg="#102a43",
            fg="white",
            insertbackground="#00f5d4",
            highlightthickness=2,
            highlightbackground="#00f5d4",
            highlightcolor="#ff4dce",
        )
        self.entrada_nombre.pack(ipady=9, pady=8)
        self.entrada_nombre.bind("<Return>", lambda _evento: self.iniciar_juego())

        self.error_nombre = tk.Label(
            self.lobby,
            text="",
            font=("Arial", 13, "bold"),
            bg="#071b2e",
            fg="#ff6b6b",
        )
        self.error_nombre.pack(pady=5)

        boton_comenzar = tk.Button(
            self.lobby,
            text="COMENZAR JUEGO",
            font=("Arial", 18, "bold"),
            bg="#00c896",
            fg="#071b2e",
            activebackground="#39ffbd",
            activeforeground="#071b2e",
            relief="flat",
            cursor="hand2",
            width=22,
            command=lambda: self.animar_accion(
                boton_comenzar,
                ("#00c896", "#c6ff00", "#00c896"),
                self.iniciar_juego,
            ),
        )
        boton_comenzar.pack(pady=16, ipady=10)
        self.agregar_hover(boton_comenzar, "#00c896", "#39ffbd")

        opciones_lobby = tk.Frame(self.lobby, bg="#071b2e")
        opciones_lobby.pack(pady=(0, 8))
        boton_instrucciones = tk.Button(
            opciones_lobby,
            text="¿CÓMO SE JUEGA?",
            font=("Arial", 18, "bold"),
            bg="#00c896",
            fg="#071b2e",
            activebackground="#39ffbd",
            activeforeground="#071b2e",
            relief="flat",
            cursor="hand2",
            width=22,
            command=lambda: self.animar_accion(
                boton_instrucciones,
                ("#00c896", "#c6ff00", "#00c896"),
                self.mostrar_instrucciones,
            ),
        )
        boton_instrucciones.pack(side="left", padx=8, ipady=10)
        self.agregar_hover(boton_instrucciones, "#00c896", "#39ffbd")
        boton_salir = tk.Button(
            opciones_lobby,
            text="SALIR",
            font=("Arial", 18, "bold"),
            bg="#00c896",
            fg="#071b2e",
            activebackground="#39ffbd",
            activeforeground="#071b2e",
            relief="flat",
            cursor="hand2",
            width=22,
            command=lambda: self.animar_accion(
                boton_salir,
                ("#00c896", "#c6ff00", "#00c896"),
                self.ventana.destroy,
            ),
        )
        boton_salir.pack(side="left", padx=8, ipady=10)
        self.agregar_hover(boton_salir, "#00c896", "#39ffbd")

    def agregar_hover(self, boton, color_base, color_hover):
        boton.bind(
            "<Enter>",
            lambda _evento: (
                None
                if boton in self.botones_animando
                else boton.config(bg=color_hover)
            ),
        )
        boton.bind(
            "<Leave>",
            lambda _evento: (
                None
                if boton in self.botones_animando
                else boton.config(bg=color_base)
            ),
        )

    def animar_accion(self, boton, colores, accion, paso=0):
        if paso == 0 and boton in self.botones_animando:
            return
        if paso == 0:
            self.botones_animando.add(boton)
        if paso < len(colores):
            boton.config(bg=colores[paso])
            self.ventana.after(
                65,
                lambda: self.animar_accion(boton, colores, accion, paso + 1),
            )
            return
        self.botones_animando.discard(boton)
        accion()

        tk.Label(
            self.lobby,
            text="PARTIDAS ANTERIORES",
            font=("Arial", 14, "bold"),
            bg="#071b2e",
            fg="#a78bfa",
        ).pack(pady=(8, 4))

        estilo = ttk.Style()
        estilo.configure(
            "Partidas.Treeview",
            font=("Arial", 10),
            rowheight=25,
            background="#102a43",
            foreground="#f7f7ff",
            fieldbackground="#102a43",
        )
        estilo.configure(
            "Partidas.Treeview.Heading",
            font=("Arial", 10, "bold"),
            background="#7b2cbf",
            foreground="white",
        )
        self.tabla_historial = ttk.Treeview(
            self.lobby,
            columns=("jugador", "resultado", "fecha"),
            show="headings",
            height=4,
            style="Partidas.Treeview",
        )
        self.tabla_historial.heading("jugador", text="Jugador")
        self.tabla_historial.heading("resultado", text="Aciertos")
        self.tabla_historial.heading("fecha", text="Fecha")
        self.tabla_historial.column("jugador", width=220)
        self.tabla_historial.column("resultado", width=120, anchor="center")
        self.tabla_historial.column("fecha", width=180, anchor="center")
        self.tabla_historial.pack(padx=100, fill="x", pady=(0, 15))
        self.actualizar_historial()

    def mostrar_instrucciones(self):
        messagebox.showinfo(
            "Cómo jugar",
            "Escribe tu nombre y pulsa COMENZAR JUEGO.\n"
            "Elige la respuesta que consideres correcta haciendo clic "
            "o usando las teclas A, B y C.\n"
            "Al final verás tu resultado y podrás jugar otra vez o volver al lobby.",
            parent=self.ventana,
        )

    def cargar_historial(self):
        try:
            contenido = self.archivo_historial.read_text(encoding="utf-8")
        except FileNotFoundError:
            return []
        except OSError as error:
            self.historial_guardable = False
            messagebox.showwarning(
                "Historial no disponible",
                f"No se pudo leer el historial anterior:\n{error}",
                parent=self.ventana,
            )
            return []

        try:
            registros = json.loads(contenido)
        except json.JSONDecodeError as error:
            self.historial_guardable = False
            messagebox.showwarning(
                "Historial dañado",
                f"El archivo del historial no tiene un formato válido:\n{error}",
                parent=self.ventana,
            )
            return []

        if not isinstance(registros, list) or any(
            not isinstance(registro, dict)
            or not all(
                clave in registro
                for clave in ("jugador", "correctas", "total", "fecha")
            )
            for registro in registros
        ):
            self.historial_guardable = False
            messagebox.showwarning(
                "Historial inválido",
                "El archivo del historial no tiene los datos esperados. "
                "Se conservará sin modificar.",
                parent=self.ventana,
            )
            return []
        return registros

    def actualizar_historial(self):
        for elemento in self.tabla_historial.get_children():
            self.tabla_historial.delete(elemento)
        for registro in reversed(self.historial[-5:]):
            try:
                fecha = datetime.fromisoformat(registro["fecha"]).strftime(
                    "%d/%m/%Y %H:%M"
                )
                aciertos = int(registro["correctas"])
                total = int(registro["total"])
                jugador = str(registro["jugador"])
            except (TypeError, ValueError):
                continue
            self.tabla_historial.insert(
                "",
                "end",
                values=(jugador, f"{aciertos}/{total}", fecha),
            )

    def guardar_resultado(self, correctas):
        if not self.historial_guardable:
            messagebox.showwarning(
                "Partida no guardada",
                "No se puede guardar porque el archivo del historial tiene un problema. "
                "El resto del juego sigue disponible.",
                parent=self.ventana,
            )
            return

        registro = {
            "jugador": self.nombre_jugador,
            "correctas": correctas,
            "total": len(self.preguntas_partida),
            "puntos": self.puntos,
            "fecha": datetime.now().isoformat(timespec="minutes"),
            "temas_bien": self.temas_correctos,
            "temas_mejorar": self.temas_por_mejorar,
        }
        nuevos_registros = self.historial + [registro]
        try:
            self.archivo_historial.write_text(
                json.dumps(nuevos_registros, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
        except OSError as error:
            messagebox.showerror(
                "No se pudo guardar",
                f"La partida terminó, pero no se pudo guardar el historial:\n{error}",
                parent=self.ventana,
            )
            return
        self.historial = nuevos_registros

    def iniciar_juego(self):
        nombre = self.entrada_nombre.get().strip()
        if not nombre:
            self.error_nombre.config(text="Por favor, escribe tu nombre para continuar.")
            self.entrada_nombre.focus_set()
            return

        self.nombre_jugador = nombre
        self.lobby.pack_forget()
        self.iniciar_partida()

    def iniciar_partida(self):
        self.indice = 0
        self.puntos = 0
        self.salud = 50
        self.temas_correctos = []
        self.temas_por_mejorar = []
        cantidad_preguntas = random.choice((2, 3, 5, 7))
        preguntas_elegidas = random.sample(preguntas, cantidad_preguntas)
        self.preguntas_partida = []
        for pregunta in preguntas_elegidas:
            pregunta_aleatoria = pregunta.copy()
            opciones = list(enumerate(pregunta["opciones"]))
            random.shuffle(opciones)
            pregunta_aleatoria["opciones"] = [
                opcion for _indice_original, opcion in opciones
            ]
            pregunta_aleatoria["correcta"] = next(
                indice_nuevo
                for indice_nuevo, (indice_original, _opcion) in enumerate(opciones)
                if indice_original == pregunta["correcta"]
            )
            self.preguntas_partida.append(pregunta_aleatoria)
        self.crear_pantalla_juego()

    def crear_pantalla_juego(self):
        self.pantalla_juego = tk.Frame(self.ventana, bg="#071b2e")
        self.pantalla_juego.pack(fill="both", expand=True)

        self.pie_resultado = tk.Frame(self.pantalla_juego, bg="#071b2e")
        self.pie_resultado.pack(side="bottom", fill="x", padx=30, pady=12)

        tk.Label(
            self.pantalla_juego,
            text=f"🌎 SALVA EL PLANETA - Jugador: {self.nombre_jugador}",
            font=("Arial", 25, "bold"),
            bg="#102a43",
            fg="#00f5d4",
            padx=18,
            pady=15,
        ).pack(fill="x", padx=25, pady=(18, 8))

        self.estado = tk.Label(
            self.pantalla_juego,
            font=("Arial", 15, "bold"),
            bg="#ff4dce",
            fg="#190b2b",
            padx=12,
            pady=8,
        )
        self.estado.pack(pady=7)

        ttk.Style().configure(
            "Verde.Horizontal.TProgressbar",
            troughcolor="#19334d",
            background="#c6ff00",
        )
        self.progreso = ttk.Progressbar(
            self.pantalla_juego,
            orient="horizontal",
            mode="determinate",
            maximum=len(self.preguntas_partida),
            style="Verde.Horizontal.TProgressbar",
        )
        self.progreso.pack(fill="x", padx=55, pady=(0, 8))

        self.cuadro_texto = tk.Text(
            self.pantalla_juego,
            height=3,
            width=70,
            wrap="word",
            font=("Arial", 19, "bold"),
            padx=20,
            pady=17,
            bg="#102a43",
            fg="#f7f7ff",
            relief="flat",
            highlightthickness=4,
            highlightbackground="#00f5d4",
        )
        self.cuadro_texto.pack(fill="x", padx=35, pady=10)
        self.cuadro_texto.config(state="disabled")

        self.etiqueta_instrucciones = tk.Label(
            self.pantalla_juego,
            text="Elige una respuesta con clic o presiona A, B o C",
            font=("Arial", 12, "bold"),
            bg="#071b2e",
            fg="#c6ff00",
        )
        self.etiqueta_instrucciones.pack(pady=(0, 3))

        self.botones = []
        self.colores_botones = [
            ("#b8ff5c", "#d1ff8a"),
            ("#63e6ff", "#9af0ff"),
            ("#ff8bd1", "#ffb3e2"),
        ]
        letras = ("A", "B", "C")
        for i, (color, color_activo) in enumerate(self.colores_botones):
            boton = tk.Button(
                self.pantalla_juego,
                text=f"{letras[i]}  |  Respuesta",
                font=("Arial", 20, "bold"),
                bg=color,
                fg="#071b2e",
                activebackground=color_activo,
                activeforeground="#071b2e",
                disabledforeground="#071b2e",
                relief="flat",
                borderwidth=0,
                highlightthickness=3,
                highlightbackground="#ffffff",
                highlightcolor="#ffffff",
                cursor="hand2",
                anchor="w",
                justify="left",
                padx=30,
                wraplength=900,
                command=lambda respuesta=i: self.seleccionar_respuesta(respuesta),
            )
            boton.pack(fill="x", padx=45, pady=7, ipady=15)
            self.botones.append(boton)
            boton.bind(
                "<Enter>",
                lambda _evento, indice=i: self.animar_hover(indice, True),
            )
            boton.bind(
                "<Leave>",
                lambda _evento, indice=i: self.animar_hover(indice, False),
            )
            self.ventana.bind(
                f"<KeyPress-{letras[i].lower()}>",
                lambda _evento, respuesta=i: self.seleccionar_respuesta(respuesta),
            )

        self.etiqueta_titulo_tabla = tk.Label(
            self.pantalla_juego,
            text="RESUMEN DE RESPUESTAS",
            font=("Arial", 14, "bold"),
            bg="#071b2e",
            fg="#ff4dce",
        )
        self.etiqueta_titulo_tabla.pack(pady=(9, 3))

        self.contenedor_tabla = tk.Frame(
            self.pantalla_juego,
            bg="#102a43",
            highlightbackground="#00f5d4",
            highlightthickness=2,
            height=135,
        )
        self.contenedor_tabla.pack(fill="x", padx=35, pady=(0, 12))
        self.contenedor_tabla.pack_propagate(False)

        estilo = ttk.Style()
        estilo.configure(
            "Historial.Treeview",
            font=("Arial", 11),
            rowheight=25,
            background="#102a43",
            foreground="#f7f7ff",
            fieldbackground="#102a43",
        )
        estilo.configure(
            "Historial.Treeview.Heading",
            font=("Arial", 11, "bold"),
            background="#7b2cbf",
            foreground="white",
        )
        columnas = ("numero", "respuesta", "resultado")
        self.tabla = ttk.Treeview(
            self.contenedor_tabla,
            columns=columnas,
            show="headings",
            height=4,
            style="Historial.Treeview",
        )
        self.tabla.heading("numero", text="#")
        self.tabla.heading("respuesta", text="Tu respuesta")
        self.tabla.heading("resultado", text="Resultado")
        self.tabla.column("numero", width=55, anchor="center", stretch=False)
        self.tabla.column("respuesta", width=600)
        self.tabla.column("resultado", width=120, anchor="center", stretch=False)
        self.tabla.tag_configure("correcta", background="#0b684f", foreground="#b7ffe6")
        self.tabla.tag_configure("incorrecta", background="#742d52", foreground="#ffd4e9")

        barra_desplazamiento = ttk.Scrollbar(
            self.contenedor_tabla,
            orient="vertical",
            command=self.tabla.yview,
        )
        self.tabla.configure(yscrollcommand=barra_desplazamiento.set)
        self.tabla.pack(side="left", fill="both", expand=True)
        barra_desplazamiento.pack(side="right", fill="y")

        self.mostrar_pregunta()

    def actualizar_texto(self, texto):
        self.cuadro_texto.config(state="normal")
        self.cuadro_texto.delete("1.0", tk.END)
        self.cuadro_texto.insert("1.0", texto)
        self.cuadro_texto.config(state="disabled")

    def mostrar_pregunta(self):
        self.respuesta_en_proceso = False
        pregunta = self.preguntas_partida[self.indice]
        self.progreso["value"] = self.indice
        self.estado.config(
            text=f"Pregunta {self.indice + 1} de {len(self.preguntas_partida)}"
            f"    |    Ronda: {len(self.preguntas_partida)} preguntas"
            f"    |    ⭐ Puntos: {self.puntos}    |    🌱 Salud: {self.salud}"
        )
        self.actualizar_texto(pregunta["pregunta"])

        for letra, boton, opcion, colores in zip(
            "ABC", self.botones, pregunta["opciones"], self.colores_botones
        ):
            boton.config(
                text=f"{letra}   |   {opcion}",
                state="normal",
                bg=colores[0],
                activebackground=colores[1],
                fg="#071b2e",
            )

    def seleccionar_respuesta(self, respuesta):
        if self.respuesta_en_proceso or self.indice >= len(self.preguntas_partida):
            return

        self.respuesta_en_proceso = True
        self.animar_respuestas(respuesta, 0)

    def animar_hover(self, indice, entrando):
        if self.respuesta_en_proceso:
            return
        boton = self.botones[indice]
        if boton["state"] == "disabled":
            return
        base, hover = self.colores_botones[indice]
        colores = (base, hover) if entrando else (hover, base)
        boton.config(bg=colores[0])
        self.ventana.after(45, lambda: boton.config(bg=colores[1]))

    def animar_respuestas(self, respuesta, paso):
        pulsos = (
            ("#ffffff", "#ffffff", "#ffffff"),
            ("#ffe45e", "#c5f3ff", "#ffd0ed"),
            ("#ffffff", "#ffffff", "#ffffff"),
        )
        if paso < len(pulsos):
            for boton, color in zip(self.botones, pulsos[paso]):
                boton.config(bg=color, fg="#071b2e")
            self.ventana.after(
                90,
                lambda: self.animar_respuestas(respuesta, paso + 1),
            )
            return

        for boton in self.botones:
            boton.config(state="disabled")
        self.procesar_respuesta(respuesta)

    def procesar_respuesta(self, respuesta):
        pregunta = self.preguntas_partida[self.indice]
        es_correcta = respuesta == pregunta["correcta"]
        fila = self.tabla.insert(
            "",
            "end",
            values=(
                self.indice + 1,
                pregunta["opciones"][respuesta],
                "Correcta" if es_correcta else "Incorrecta",
            ),
            tags=("correcta" if es_correcta else "incorrecta",),
        )
        self.tabla.see(fila)
        if es_correcta:
            self.puntos += 10
            self.salud += 15
            if pregunta["tema"] not in self.temas_correctos:
                self.temas_correctos.append(pregunta["tema"])
            resultado = "¡Correcto! " + pregunta["explicacion"]
        else:
            self.salud -= 10
            if pregunta["tema"] not in self.temas_por_mejorar:
                self.temas_por_mejorar.append(pregunta["tema"])
            respuesta_correcta = pregunta["opciones"][pregunta["correcta"]]
            resultado = (
                f"No era esa. La mejor opción es: {respuesta_correcta}. "
                f"{pregunta['explicacion']}"
            )

        self.indice += 1
        self.progreso["value"] = self.indice
        if self.indice < len(self.preguntas_partida):
            self.actualizar_texto(resultado + "\n\nSiguiente pregunta...")
            self.ventana.after(1700, self.mostrar_pregunta)
        else:
            self.mostrar_resultado()

    def mostrar_resultado(self):
        self.estado.config(text="RESULTADO FINAL")
        correctas = self.puntos // 10
        fortalezas = ", ".join(self.temas_correctos[:2]) or "¡Sigue aprendiendo!"
        mejora = ", ".join(self.temas_por_mejorar[:3]) or "¡Dominaste todos los temas!"
        if len(self.temas_por_mejorar) > 3:
            mejora += " y otros"
        felicitacion = (
            "¡Excelente trabajo!"
            if correctas >= len(self.preguntas_partida) * 0.7
            else "¡Buen esfuerzo!"
        )
        self.actualizar_texto(
            f"🏆 {felicitacion} — {self.nombre_jugador}: "
            f"{correctas}/{len(self.preguntas_partida)} correctas ({self.puntos} puntos).\n"
            f"💚 Te fue bien en: {fortalezas}.\n"
            f"📘 Puedes mejorar en: {mejora}."
        )
        self.guardar_resultado(correctas)
        self.actualizar_historial()
        for boton in self.botones:
            boton.config(state="disabled")
            boton.pack_forget()
        self.etiqueta_instrucciones.pack_forget()
        self.etiqueta_titulo_tabla.pack_forget()
        self.contenedor_tabla.pack_forget()
        self.progreso["value"] = len(self.preguntas_partida)
        self.progreso.pack_forget()
        self.cuadro_texto.config(height=5)
        boton_repetir = tk.Button(
            self.pie_resultado,
            text="↻  JUGAR DE NUEVO",
            font=("Arial", 15, "bold"),
            bg="#00c896",
            fg="#071b2e",
            activebackground="#00e0aa",
            activeforeground="#071b2e",
            relief="flat",
            cursor="hand2",
            padx=18,
            pady=6,
            command=lambda: self.animar_accion(
                boton_repetir,
                ("#00c896", "#c6ff00", "#00c896"),
                self.jugar_de_nuevo,
            ),
        )
        boton_repetir.pack(side="left", expand=True, padx=8, ipadx=16, ipady=10)
        self.agregar_hover(boton_repetir, "#00c896", "#39ffbd")
        boton_lobby = tk.Button(
            self.pie_resultado,
            text="⌂  VOLVER AL LOBBY",
            font=("Arial", 15, "bold"),
            bg="#ff4dce",
            fg="#071b2e",
            activebackground="#ff85df",
            activeforeground="#071b2e",
            relief="flat",
            cursor="hand2",
            padx=18,
            pady=6,
            command=lambda: self.animar_accion(
                boton_lobby,
                ("#ff4dce", "#c6ff00", "#ff4dce"),
                self.volver_al_lobby,
            ),
        )
        boton_lobby.pack(side="left", expand=True, padx=8, ipadx=16, ipady=12)
        self.agregar_hover(boton_lobby, "#ff4dce", "#ff85df")

    def jugar_de_nuevo(self):
        self.limpiar_pantalla_juego()
        self.iniciar_partida()

    def volver_al_lobby(self):
        self.limpiar_pantalla_juego()
        self.entrada_nombre.delete(0, tk.END)
        self.error_nombre.config(text="")
        self.lobby.pack(fill="both", expand=True)
        self.entrada_nombre.focus_set()

    def limpiar_pantalla_juego(self):
        for letra in "abc":
            self.ventana.unbind(f"<KeyPress-{letra}>")
        self.pantalla_juego.destroy()
        self.respuesta_en_proceso = False


if __name__ == "__main__":
    ventana = tk.Tk()
    Cuestionario(ventana)
    ventana.mainloop()
